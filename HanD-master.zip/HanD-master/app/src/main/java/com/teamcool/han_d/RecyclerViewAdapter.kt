package com.teamcool.han_d

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecyclerViewAdapter(var gestureData: Array<Gesture>) :
    RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder>() {

    class RecyclerViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        fun bind(gesture_item: Gesture) {
//            view.findViewById<TextView>(R.id.view_gesture).text = gesture_item.gestureName
//            view.findViewById<TextView>(R.id.view_translation).text = gesture_item.gestureTranslation
//            view.findViewById<TextView>(R.id.view_timestamp).text = gesture_item.gestureTimestamp
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerViewHolder {
        val viewItem = LayoutInflater.from(parent.context).inflate(
            R.layout.gesture_item,
            parent,
            false
        )
        val rholder = RecyclerViewHolder(viewItem)
        return rholder
    }

    override fun onBindViewHolder(holder: RecyclerViewHolder, position: Int) {
        holder.bind(gestureData[position])
    }
    override fun getItemCount(): Int {
        return gestureData.size
    }
}