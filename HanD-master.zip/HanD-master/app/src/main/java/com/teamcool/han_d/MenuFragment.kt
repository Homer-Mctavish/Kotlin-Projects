package com.teamcool.han_d

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.fragment.findNavController

class MenuFragment : Fragment() {
    lateinit var calibrationButton: Button
    lateinit var singleGestureButton: Button
    lateinit var continousButton: Button
    lateinit var customButton: Button
    lateinit var savedGestureButton: Button


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_menu, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        calibrationButton = view.findViewById(R.id.calibrate_button)
        singleGestureButton = view.findViewById(R.id.singleGesture_button)
        continousButton = view.findViewById(R.id.continous_button)
        customButton = view.findViewById(R.id.record_button)
        savedGestureButton = view.findViewById(R.id.saved_button)

        calibrationButton.setOnClickListener { mainMenuButtonClick(0) }
        singleGestureButton.setOnClickListener { mainMenuButtonClick(1) }
        continousButton.setOnClickListener { mainMenuButtonClick(2) }
        customButton.setOnClickListener { mainMenuButtonClick(3) }
        savedGestureButton.setOnClickListener { mainMenuButtonClick(4) }
    }

    fun mainMenuButtonClick(num:Int)
    {
        when(num)
        {
            0 -> findNavController().navigate(R.id.action_global_calibrationFragment)
            1 -> findNavController().navigate(R.id.action_global_singleGestureFragment)
            2 -> findNavController().navigate(R.id.action_global_continousTranslationFragment)
            3 -> findNavController().navigate(R.id.action_global_recordGestureFragment)
            4 -> findNavController().navigate(R.id.action_global_savedGesturesFragment)
            else -> findNavController().navigate(R.id.action_global_menuFragment)
        }
    }
}