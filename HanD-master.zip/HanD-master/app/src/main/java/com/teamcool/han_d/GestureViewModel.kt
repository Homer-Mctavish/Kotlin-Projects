package com.teamcool.han_d

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
class GestureViewModel: ViewModel(),ValueEventListener {
    //variables
    var currentGesture = MutableLiveData<Gesture>()
    var gestureList = MutableLiveData<ArrayList<Gesture>>()
    var database = MutableLiveData<DatabaseReference>()

    //initializing values
    init{
//        currentGesture.value = Gesture("0","0","0","0","0")
        gestureList.value = ArrayList()
        database.value = Firebase.database.getReference("")
        database.value?.addValueEventListener(this)
    }

    override fun onDataChange(snapshot: DataSnapshot) {
        val gestures = ArrayList<Gesture>()
        snapshot.children.forEach{
            val gesture = it.getValue(Gesture::class.java)
            if(gesture != null){
                gestures.add(gesture)
            }
        }
        gestureList.value = gestures
        gestureList.postValue(gestures)
    }

    override fun onCancelled(error: DatabaseError) {
    }


    fun setCurrentGesture(gesture: Gesture){
        currentGesture.value = gesture
    }

}