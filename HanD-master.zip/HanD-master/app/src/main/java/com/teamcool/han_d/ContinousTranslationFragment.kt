package com.teamcool.han_d

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context.CLIPBOARD_SERVICE
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController

class ContinousTranslationFragment : Fragment() {
    val viewModel:GestureViewModel by viewModels()

    lateinit var backButton: Button
    lateinit var copyButton: Button
    lateinit var clearButton: Button
    lateinit var retryButton: Button
    lateinit var inputText: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_continous_translation, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        backButton = view.findViewById(R.id.BackBtn)
        copyButton = view.findViewById(R.id.CopyBtn)
        clearButton = view.findViewById(R.id.ClearBtn)
        inputText = view.findViewById(R.id.input_text)
        retryButton = view.findViewById(R.id.RetryBtn)

        retryButton.setOnClickListener{
            val text = inputText.text.toString().dropLast(1)
            Log.d("InputText", text)
            inputText.text = text
        }

        copyButton.setOnClickListener {
            val clipboardManager =
            context?.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clipData: ClipData = ClipData.newPlainText("text", inputText.text)
            clipboardManager.setPrimaryClip(clipData)

            Toast.makeText(context, "Copied to Clipboard", Toast.LENGTH_SHORT).show()
        }

        clearButton.setOnClickListener {
            inputText.text = ""
        }
        backButton.setOnClickListener { findNavController().navigate(R.id.action_global_menuFragment) }
    }
}