package com.teamcool.han_d

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.util.*
import android.os.AsyncTask
import android.system.Os.socket
import android.widget.Button
import kotlinx.coroutines.*
import java.io.*
import java.util.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.consumeEach
//import kotlinx.coroutines.channels.Channel.Factory.CONCURRENT
import java.util.concurrent.ConcurrentLinkedQueue

class MainActivity : AppCompatActivity() {
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private lateinit var device: BluetoothDevice
    private lateinit var bluetoothsocket: BluetoothSocket
    lateinit var thumb: TextView
    lateinit var index: TextView
    lateinit var middle: TextView
    lateinit var ring: TextView
    lateinit var little: TextView
    lateinit var connect: Button
    lateinit var backButton: Button
    private val uuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    val viewModel:GestureViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//        thumb = findViewById(R.id.thumb)
//        index = findViewById(R.id.indexFinger)
//        middle = findViewById(R.id.middleFinger)
//        ring = findViewById(R.id.ringFinger)
//        little = findViewById(R.id.littleFinger)
//        connect = findViewById(R.id.ConnectBtn)
//        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
//        device = bluetoothAdapter.getRemoteDevice("98:D3:31:FD:C5:43")
//        /* check for an active connection using the Adapter device */
//        if (ContextCompat.checkSelfPermission(
//                this,
//                Manifest.permission.BLUETOOTH_ADMIN
//            ) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
//                this,
//                Manifest.permission.BLUETOOTH
//            ) != PackageManager.PERMISSION_GRANTED
//        ) {
//            ActivityCompat.requestPermissions(
//                this,
//                arrayOf(Manifest.permission.BLUETOOTH_ADMIN, Manifest.permission.BLUETOOTH),
//                101
//            )
//        }
//        bluetoothAdapter.cancelDiscovery()
//        val to = Toast.makeText(applicationContext, "we did it", Toast.LENGTH_LONG)
//        to.show()
//        try {
//            bluetoothsocket = device.createRfcommSocketToServiceRecord(uuid)
//            /* Here is the part the connection is made, by asking the device to create a RfcommSocket (Unsecure socket I guess), It map a port for us or something like that */
//            bluetoothsocket.connect()
//            val toast = Toast.makeText(applicationContext, "Connection made.", Toast.LENGTH_LONG)
//            toast.show()
//            Toast.makeText(applicationContext, "Connection made.", Toast.LENGTH_SHORT).show()
//        } catch (e: IOException) {
//            try {
//                bluetoothsocket.close()
//            } catch (e2: IOException) {
//                Log.d("", "Unable to end the connection")
//                Toast.makeText(
//                    applicationContext,
//                    "Unable to end the connection",
//                    Toast.LENGTH_SHORT
//                ).show()
//            }
//            Log.d("", "Socket creation failed")
//            Toast.makeText(applicationContext, "Socket creation failed", Toast.LENGTH_SHORT).show()
//        }
//
//        // Read data from the input stream
//        val inputStream = bluetoothsocket.inputStream
//// Create a globally scoped coroutine to communicate the data between activites during coexecution
//        GlobalScope.launch {
//            // Create a BufferedReader to read the InputStream
//            val reader = BufferedReader(InputStreamReader(inputStream))
//            // Read lines of text from the BufferedReader and send them to the channel
//            var stringBuilder = StringBuilder()
//            while (true) {
//                val c = reader.read().toChar()
//                if (c==';'){
//                    val sensorinfo = stringBuilder.toString()
//                    val split = sensorinfo.split(',')
//                    thumb.text = split[0]
//                    index.text = split[1]
//                    middle.text = split[2]
//                    ring.text = split[3]
//                    little.text = split[4]
//
//                    stringBuilder.clear()
//                }else{
//                    stringBuilder.append(c)
//                }
//            }
//        }
//
//        //inputStream.close()

    }

}