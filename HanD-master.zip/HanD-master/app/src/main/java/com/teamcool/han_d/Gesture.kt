package com.teamcool.han_d

class Gesture(data:String){

//    var gesturePic = 0
//    var gestureName = ""
//    var gestureTranslation = ""
//    var gestureTimestamp = ""
}