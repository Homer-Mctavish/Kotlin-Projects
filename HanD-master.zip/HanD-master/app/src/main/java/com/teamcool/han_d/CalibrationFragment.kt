package com.teamcool.han_d

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.util.*
import android.os.AsyncTask
import android.os.Handler
import android.os.Looper
import android.system.Os.socket
import kotlinx.coroutines.*
import java.io.*
import java.util.*


class CalibrationFragment : Fragment() {
    val viewModel:GestureViewModel by viewModels()
    lateinit var thumb: TextView
    lateinit var index: TextView
    lateinit var middle: TextView
    lateinit var ring: TextView
    lateinit var little: TextView
    lateinit var connect: Button
    lateinit var backButton: Button

    lateinit var bluetoothAdapter: BluetoothAdapter
    lateinit var device: BluetoothDevice
    lateinit var bluetoothsocket: BluetoothSocket
    val uuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        thumb = view.findViewById(R.id.thumbo)
        index = view.findViewById(R.id.indexer)
        middle = view.findViewById(R.id.middler)
        ring = view.findViewById(R.id.ringer)
        little = view.findViewById(R.id.littler)
        connect = view.findViewById(R.id.ConnectBtn)
        backButton  = view.findViewById(R.id.BackBtn)
        backButton.setOnClickListener { findNavController().navigate(R.id.action_global_menuFragment) }

        connect.setOnClickListener{
            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
            device = bluetoothAdapter.getRemoteDevice("98:D3:31:FD:C5:43")
            /* check for an active connection using the Adapter device */
            if (ContextCompat.checkSelfPermission(
                    this.requireContext(),
                    Manifest.permission.BLUETOOTH_ADMIN
                ) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                    this.requireContext(),
                    Manifest.permission.BLUETOOTH
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this.requireActivity(),
                    arrayOf(Manifest.permission.BLUETOOTH_ADMIN, Manifest.permission.BLUETOOTH),
                    101
                )
            }
            bluetoothAdapter.cancelDiscovery()
            try {
                bluetoothsocket = device.createRfcommSocketToServiceRecord(uuid)
                /* Here is the part the connection is made, by asking the device to create a RfcommSocket (Unsecure socket I guess), It map a port for us or something like that */
                bluetoothsocket.connect()
                Toast.makeText(this.context, "Connection made.", Toast.LENGTH_SHORT).show()
            } catch (e: IOException) {
                try {
                    bluetoothsocket.close()
                } catch (e2: IOException) {
                    Log.d("", "Unable to end the connection")
                    Toast.makeText(
                        this.context,
                        "Unable to end the connection",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                Log.d("", "Socket creation failed")
                Toast.makeText(this.context, "Socket creation failed", Toast.LENGTH_SHORT).show()
            }

//             Read data from the input stream
            val inputStream = bluetoothsocket.inputStream
            //Create a globally scoped coroutine to communicate the data between activites during coexecution
            GlobalScope.launch {

                // Create a BufferedReader to read the InputStream
                val reader = BufferedReader(InputStreamReader(inputStream))
                // Read lines of text from the BufferedReader and send them to the channel
                var stringBuilder = StringBuilder()
                while (true) {
                    val c = reader.read().toChar()
                    if (c==';'){
                        val sensorinfo = stringBuilder.toString()
                        requireActivity().runOnUiThread {
                            val g = sensorinfo.split(",")
                            thumb.text = g[0]
                            index.text = g[1]
                            middle.text = g[2]
                            ring.text = g[3]
                            little.text = g[4]
                        }
                        stringBuilder.clear()
                    }else{
                        stringBuilder.append(c)
                    }
                }
            }

            //inputStream.close()
        }


        //thumb.text= viewModel.currentGesture.value.toString()

    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_calibration, container, false)
    }


}