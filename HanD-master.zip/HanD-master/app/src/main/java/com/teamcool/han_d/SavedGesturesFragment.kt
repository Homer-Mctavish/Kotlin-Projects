package com.teamcool.han_d

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class SavedGesturesFragment : Fragment() {

    val viewModel: GestureViewModel by viewModels()

    lateinit var viewManager: LinearLayoutManager
    lateinit var viewAdapter: RecyclerViewAdapter

    lateinit var gesture_recyclerView: RecyclerView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        gesture_recyclerView = view.findViewById(R.id.gesture_recycler)
        viewAdapter = RecyclerViewAdapter(emptyArray())

        gesture_recyclerView.layoutManager = viewManager
        gesture_recyclerView.adapter = viewAdapter

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_saved_gestures, container, false)
    }
}